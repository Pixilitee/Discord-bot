# 🤖 Discord Bot — Setup Guide (No PC Needed!)

## Step 1 — Create Your Bot on Discord

1. Go to **https://discord.com/developers/applications**
2. Click **"New Application"** → give it a name → click **Create**
3. Click **"Bot"** on the left sidebar
4. Click **"Add Bot"** → **"Yes, do it!"**
5. Under **Privileged Gateway Intents**, turn ON:
   - ✅ Server Members Intent
   - ✅ Message Content Intent
6. Click **"Reset Token"** → copy the token (keep it secret!)
7. Click **"OAuth2"** → **"URL Generator"**
   - Check: `bot` and `applications.commands`
   - Bot Permissions: check `Administrator`
8. Copy the URL at the bottom → open it → invite the bot to your server

---

## Step 2 — Set Up on Replit (Free, works on phone!)

1. Go to **https://replit.com** and create a free account
2. Click **"+ Create Repl"**
3. Choose **Node.js** as the template
4. Name it `discord-bot` → click **Create**

---

## Step 3 — Upload the Files

In Replit, you'll see a file panel on the left.

1. Delete the default `index.js` content
2. Create these files and paste the code from each file you downloaded:
   - `index.js`
   - `commands/help.js`
   - `commands/moderation.js`
   - `commands/giveaway.js`
   - `commands/poll.js`
   - `commands/xp.js`
   - `commands/helper.js`
   - `package.json`

---

## Step 4 — Add Your Bot Token (Securely)

1. In Replit, click the 🔒 **"Secrets"** tab (padlock icon on the left)
2. Click **"+ New Secret"**
   - Key: `TOKEN`
   - Value: (paste your bot token from Step 1)
3. Click **"Add Secret"**

---

## Step 5 — Run the Bot!

1. In Replit, click the **"Packages"** tab and install: `discord.js`
2. Click the green **▶ Run** button
3. You should see: `✅ Bot is online as YourBot#1234`

---

## Step 6 — Keep it Online 24/7 (Free)

Replit sleeps after inactivity. To keep it awake:

1. Go to **https://uptimerobot.com** → create a free account
2. Add a new monitor:
   - Type: HTTP(s)
   - URL: your Replit project URL (shown in the browser tab when running)
   - Interval: every 5 minutes
3. This pings your bot every 5 minutes so it stays awake!

---

## 📋 All Commands

| Command | Description | Who can use |
|---|---|---|
| `!help` | List all commands | Everyone |
| `!rank` | See your XP & level | Everyone |
| `!leaderboard` | Top 10 XP board | Everyone |
| `!poll Question \| Opt1 \| Opt2` | Create a poll | Everyone |
| `!pollresults [messageId]` | View poll results | Everyone |
| `!giveaway [mins] [prize]` | Start a giveaway | Manage Server |
| `!greroll [messageId]` | Reroll giveaway | Manage Server |
| `!announce [message]` | Send announcement | Manage Messages |
| `!say [message]` | Bot says message | Manage Messages |
| `!warn @user [reason]` | Warn a user | Manage Messages |
| `!mute @user [minutes]` | Mute a user | Moderate Members |
| `!kick @user [reason]` | Kick a user | Kick Members |
| `!ban @user [reason]` | Ban a user | Ban Members |
| `!clear [amount]` | Delete messages | Manage Messages |

---

## ⚙️ Customizing the Bot

Open `index.js` and change these near the top:

```js
// Add your bad words here:
const BAD_WORDS = ['badword1', 'badword2'];

// Max user mentions before auto-delete:
const MAX_MENTIONS = 5;

// % of caps before auto-delete:
const MAX_CAPS_PERCENT = 70;

// Your welcome channel name:
const WELCOME_CHANNEL_NAME = 'welcome';
```

---

## ✅ Features Summary

- 🛡️ **Auto-Mod** — Deletes bad words, mass mentions, and caps spam automatically
- 🎉 **Giveaways** — Timed giveaways with 🎉 reaction entry and random winner
- ⭐ **XP System** — Users earn XP for chatting, level up with announcements
- 📊 **Polls** — Up to 5-option polls with live reaction voting and results
- 👋 **Welcome Messages** — Auto-welcomes new members in your welcome channel
- 📢 **Announcements** — Mods can send styled announcements or make the bot say things
